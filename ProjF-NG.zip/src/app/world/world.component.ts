import { Component, OnInit } from '@angular/core';
import { Global } from '../global';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-world',
  templateUrl: './world.component.html',
  styleUrls: ['./world.component.css']
})
export class WorldComponent implements OnInit {
  title = "The Country Game";
  country : string;
  status;
  result;
  showStatus: boolean;

  constructor(private http: HttpClient) { this.showStatus = false;}

  ngOnInit() {
  this.country = '';
  this.query ='';
	
  }
  
  
 submitted = false;
	
	  capital() {
		this.submitted = true;
		this.http.get(Global.WORLD_URL + "?country="+this.country+"&query=capital&key=72018")
				.subscribe(data =>
				{
				   const resp = JSON.parse(JSON.stringify(data));
				   this.result = resp.response;
					
				   console.log(this.status);
				   if (this.result.match("Invalid"))
				   {
					  this.showStatus = true;
					  this.result = resp.response;
					
				   }
					   

				});
			   console.log("outside");
	  
	  }
	  pop() {
		this.submitted = true;
		this.http.get(Global.WORLD_URL + "?country="+this.country+"&query=pop&key=72018")
				.subscribe(data =>
				{
				   const resp = JSON.parse(JSON.stringify(data));
				   this.result = resp.response;
					
				   console.log(this.status);
				   if (this.result.match("Invalid"))
				   {
					  this.showStatus = true;
					  this.result = resp.response;
					
				   }
					   

				});
			   console.log("outside");
	  }
	  
	  prefix() {
		this.submitted = true;
		this.http.get(Global.WORLD_URL + "?country="+this.country+"&query=prefix&key=72018")
				.subscribe(data =>
				{
				   const resp = JSON.parse(JSON.stringify(data));
				   this.result = resp.response;
					
				   console.log(this.status);
				   if (this.result.match("Invalid"))
				   {
					  this.showStatus = true;
					  this.result = resp.response;
					
				   }
					   

				});
			   console.log("outside");
	  }
}

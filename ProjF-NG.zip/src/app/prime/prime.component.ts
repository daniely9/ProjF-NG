import { Component, OnInit } from '@angular/core';
import { Global } from '../global';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-prime',
  templateUrl: './prime.component.html',
  styleUrls: ['./prime.component.css']
})
export class PrimeComponent implements OnInit {
  title="Prime Finder";
  min;
  max;
  status;
  result;
  showStatus: boolean;
  
  constructor(private http: HttpClient) { this.showStatus = false;}

  ngOnInit() {
  }

  submitted = false;
  onSubmit()
  {
    this.submitted = true;

    this.http.get(Global.PRIME_URL + "?min="+this.min+"&max="+this.max)
            .subscribe(data =>
            {
               const resp = JSON.parse(JSON.stringify(data));
               this.status = resp.status;
               this.result = resp.result;
               console.log(this.status);
               if (this.status == "0")
               {
                  this.showStatus = true;
                  this.result = resp.error;
                
               }
                   

            });
           console.log("outside");
  
  }
  findNext() 
  {
	this.min = this.result;
	this.onSubmit();
  }


}

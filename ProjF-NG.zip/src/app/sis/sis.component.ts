import { Component, OnInit } from '@angular/core';
import { Global } from '../global';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sis',
  templateUrl: './sis.component.html',
  styleUrls: ['./sis.component.css']
})
export class SisComponent implements OnInit {

	title = "SIS Report Generator";
	prefix : string;
	minGpa : string;
	sortBy : string;
	
	status : boolean;
	submitted  : boolean;
	result : string[];
	

  constructor(private http: HttpClient)
  {
   
  }

  ngOnInit() {
	this.prefix = '';
	this.minGpa = '';
	this.sortBy = 'NONE';
	this.submitted = false;
   }


  onSubmit()
  {
   
    this.http.get(Global.SIS_URL + "?prefix="+this.prefix+"&minGpa="+this.minGpa+"&sortBy="+this.sortBy)
            .subscribe(data => {
               const resp = JSON.parse(JSON.stringify(data));
               this.status = resp.status;
               this.result = resp.data;
               this.submitted = true;
               alert(this.status);
               
               
            });
             this.submitted = true;
  }
}

	
	

export class Global
{
  public static readonly PRIME_URL = "http://localhost:4413/ProjF/Prime.do";
  public static readonly SIS_URL = "http://localhost:4413/ProjF/Sis.do";
  public static readonly WORLD_URL = "https://www.eecs.yorku.ca/~roumani/servers/4413/f18/world.cgi";
}
